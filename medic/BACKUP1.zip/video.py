import os
import cv2
import shutil


def frames_to_video(frames_folder, output_video_path, fps=2):
    image_files = []

    # Traverse through all subdirectories in frames_folder
    for root, dirs, files in os.walk(frames_folder):
        for file in files:
            if file.endswith('.png'):
                image_files.append(os.path.join(root, file))

    if not image_files:
        print(f"No PNG image files found in {frames_folder}")
        return

    # Sort the image files
    image_files.sort()

    # Get dimensions of the first image
    img = cv2.imread(image_files[0])
    if img is None:
        print(f"Failed to read {image_files[0]}. Check if the file exists and is accessible.")
        return
    height, width, _ = img.shape

    # Define the codec and create VideoWriter object
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # You can change the codec as per your requirement
    out = cv2.VideoWriter(output_video_path, fourcc, fps, (width, height))

    # Write frames to video
    total_frames = len(image_files)
    frame_count = 0
    for image_file in image_files:
        img = cv2.imread(image_file)
        if img is None:
            print(f"Failed to read {image_file}. Skipping...")
            continue
        # Overlay frame counter onto the image
        frame_count += 1
        text = f'Frame: {frame_count} / {total_frames}'
        cv2.putText(img, text, (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA)
        # Write each frame multiple times to make it appear for 0.5 seconds
        for _ in range(int(fps * 0.5)):
            out.write(img)

    # Release the VideoWriter object
    out.release()


def copy_video_to_new_folder(output_video_path, new_folder_name):
    # Create the new folder if it doesn't exist
    os.makedirs(new_folder_name, exist_ok=True)
    # Check if the video file exists
    if os.path.exists(output_video_path):
        # Copy the video to the new folder
        shutil.copy(output_video_path, os.path.join(new_folder_name, os.path.basename(output_video_path)))
    else:
        print(f"No video file found at {output_video_path}")

if __name__ == "__main__":
    frames_parent_folder = "images"  # Assuming the images are in images folder

    for root, dirs, files in os.walk(frames_parent_folder):
        for folder in dirs:
            frames_folder = os.path.join(root, folder)
            output_video_path = os.path.join(frames_folder, "output_video.mp4")
            fps = 2  # Frames per second (each frame will be displayed for 0.5 seconds)

            frames_to_video(frames_folder, output_video_path, fps)
            # Extract the folder name from the frames_folder
            folder_name = os.path.basename(frames_folder)
            # Create a new folder named "video" in the parent directory
            new_folder_path = os.path.join(os.path.dirname(frames_folder), "video")
            # Copy the video to the new folder with the folder name
            copy_video_to_new_folder(output_video_path, os.path.join(new_folder_path, folder_name))
