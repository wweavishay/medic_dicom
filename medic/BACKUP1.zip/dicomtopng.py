import os
import pydicom
import matplotlib.pyplot as plt
import numpy as np

def convert_dicom_to_png(input_folder, output_folder):
    os.makedirs(output_folder, exist_ok=True)
    for filename in os.listdir(input_folder):
        if filename.endswith('.dcm'):
            dicom_path = os.path.join(input_folder, filename)
            dicom_data = pydicom.dcmread(dicom_path)
            pixel_array = dicom_data.pixel_array
            output_path = os.path.join(output_folder, os.path.splitext(filename)[0] + '.png')
            plt.imsave(output_path, pixel_array, cmap='bone')

def main():
    input_folder = "images/dicomfiles"
    output_folder = "images/pngfiles"
    convert_dicom_to_png(input_folder, output_folder)
    print("DICOM files converted to PNG.")

if __name__ == "__main__":
    main()
