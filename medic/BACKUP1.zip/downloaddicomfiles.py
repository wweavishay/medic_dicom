import os
import requests
from random import sample

# Function to fetch series instance UIDs for a given modality and body part
def fetch_series_instance_uids(modality, body_part_examined, max_results=1000):
    url = 'https://services.cancerimagingarchive.net/services/v3/TCIA/query/getCollectionValues'
    params = {
        'Collection': 'CMB-LCA',  # Specify the collection name
        'Modality': modality,
        'BodyPartExamined': body_part_examined,
        'format': 'json'
    }
    response = requests.get(url, params=params)
    if response.status_code == 200:
        data = response.json()
        return [item['Collection'] for item in data[:min(max_results, len(data))]]
    else:
        print("Failed to fetch series instance UIDs:", response.text)
        return []

# Function to download DICOM images for a given series instance UID
def download_dicom_images(series_instance_uid, output_dir):
    url = f'https://services.cancerimagingarchive.net/services/v3/TCIA/query/getImage?SeriesInstanceUID={series_instance_uid}'
    response = requests.get(url)
    if response.status_code == 200:
        with open(output_dir, 'wb') as f:
            f.write(response.content)
        print(f"Downloaded DICOM images for series instance UID: {series_instance_uid}")
    else:
        print(f"Failed to download DICOM images for series instance UID: {series_instance_uid}")

# Specify the directory to save the DICOM images
base_dir = 'images_dcm'
os.makedirs(base_dir, exist_ok=True)

# Fetch real series instance UIDs for Brain MRI and Chest CT
brain_mri_series_instance_uids = fetch_series_instance_uids(modality='MR', body_part_examined='BRAIN')
chest_ct_series_instance_uids = fetch_series_instance_uids(modality='CT', body_part_examined='CHEST')

# Select a subset of series instance UIDs
selected_brain_mri_uids = sample(brain_mri_series_instance_uids, min(1000, len(brain_mri_series_instance_uids)))
selected_chest_ct_uids = sample(chest_ct_series_instance_uids, min(1000, len(chest_ct_series_instance_uids)))

# Download DICOM images for Brain MRI
brain_mri_dir = os.path.join(base_dir, 'Brain_MRI')
os.makedirs(brain_mri_dir, exist_ok=True)
for i, uid in enumerate(selected_brain_mri_uids):
    download_dicom_images(uid, os.path.join(brain_mri_dir, f'brain_mri_image_{i}.dcm'))

# Download DICOM images for Chest CT
chest_ct_dir = os.path.join(base_dir, 'Chest_CT')
os.makedirs(chest_ct_dir, exist_ok=True)
for i, uid in enumerate(selected_chest_ct_uids):
    download_dicom_images(uid, os.path.join(chest_ct_dir, f'chest_ct_image_{i}.dcm'))

print("DICOM images downloaded successfully.")
